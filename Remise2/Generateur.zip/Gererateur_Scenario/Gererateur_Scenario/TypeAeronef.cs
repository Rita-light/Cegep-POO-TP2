﻿namespace Gererateur_Scenario
{
    public enum TypeAeronef
    {
        Passager,
        Cargo,
        Secours,
        Citerne,
        Helicoptere
        
    }
    
}