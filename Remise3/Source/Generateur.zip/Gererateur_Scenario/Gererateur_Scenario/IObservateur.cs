﻿namespace Gererateur_Scenario
{
    public interface IObservateur
    {
        void MettreAJour();
    }
}