﻿namespace Gererateur_Scenario
{
    public enum TypeEtat
    {
        Entretien,
        Vol,
        Sol,
        Embarquement,
        Debarquement
    }
}