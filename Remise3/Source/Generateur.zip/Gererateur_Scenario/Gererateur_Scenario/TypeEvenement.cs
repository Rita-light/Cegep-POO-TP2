﻿namespace Gererateur_Scenario
{
    public enum TypeEvenement
    {
        Passager,
        Cargaison,
        Secours,
        Incendie,
        Observation
    }
}