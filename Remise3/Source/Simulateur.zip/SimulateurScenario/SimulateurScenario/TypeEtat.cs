﻿namespace SimulateurScenario;

    public enum TypeEtat
    {
        Entretien,
        Vol,
        Sol,
        Embarquement,
        Debarquement  
    }
