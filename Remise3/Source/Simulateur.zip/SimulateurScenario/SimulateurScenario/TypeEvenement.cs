﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimulateurScenario
{
    public enum TypeEvenement
    {
        Passager,
        Cargaison,
        Secours,
        Incendie,
        Observation, 
        ChargementTermine,
        NouveauClient,
        AfficherVol,
        EvenementTermine
        
        
    }
}
